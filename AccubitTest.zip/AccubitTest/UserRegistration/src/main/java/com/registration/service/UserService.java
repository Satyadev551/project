package com.registration.service;

import com.registration.model.User;

public class UserService {

	public void register(User user) {
		// TODO Auto-generated method stub
		
	}

}
