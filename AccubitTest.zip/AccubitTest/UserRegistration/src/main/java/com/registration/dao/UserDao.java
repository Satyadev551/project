package com.registration.dao;

import com.registration.model.Login;
import com.registration.model.User;

public interface UserDao {
	
	void register(User user);
	User validateUser(Login login);
}
